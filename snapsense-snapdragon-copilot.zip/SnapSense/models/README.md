# Models

SnapSense uses pre-optimized models from Qualcomm AI Hub (https://aihub.qualcomm.com):

- Llama-3.2-3B-Instruct (INT4), language reasoning
- Whisper-Base (INT8), transcription
- CLIP-ViT / MobileNetV4, embeddings

Download or export them by following the model pages on Qualcomm AI Hub, and place the
resulting `.onnx` files in this folder (they are git-ignored because of their size).
