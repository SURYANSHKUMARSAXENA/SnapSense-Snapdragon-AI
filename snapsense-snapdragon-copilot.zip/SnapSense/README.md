# SnapSense: On-Device Multimodal Copilot for Snapdragon® HP PCs

> Built for the **Snapdragon® AI Lab Build & Present Challenge** | Qualcomm & HP
> Target platform: Snapdragon® X Elite / X Plus on HP Copilot+ PCs (Windows on ARM64)

## 1. Overview
SnapSense is an on-device, multimodal contextual assistant designed to use the 45 TOPS Qualcomm® Hexagon™ NPU on Snapdragon-powered HP PCs. Screen reasoning, local document search, and meeting transcription are designed to run 100% offline, for privacy, low latency, and low power draw.

## 2. Key Features
- **Ambient Audio Scribe:** live transcription and action-item generation with quantized Whisper on the NPU.
- **Zero-Leak Screen Parsing:** local screen capture and embedding across open application windows.
- **Offline Contextual RAG:** semantic search over local documents, notes, and code with a local vector index.
- **NPU Offload:** tensor ops directed to the Hexagon NPU, freeing the Oryon™ CPU and Adreno™ GPU.

## 3. Snapdragon & Qualcomm AI Hub Integration
- **Models (from Qualcomm AI Hub):** Llama-3.2-3B-Instruct (INT4), Whisper-Base (INT8), CLIP-ViT / MobileNetV4.
- **Runtime:** ONNX Runtime with the Qualcomm® QNN Execution Provider, HTP backend (Hexagon NPU). See `src/common/session.py`.

## 4. Design Targets
Sub-25 ms time-to-first-token, 28+ tokens/sec, sustained under 5 W, up to 70% lower energy draw than GPU-based local execution, and full operation with networking disabled. These are design targets; measured results will be added here.

## 5. Implementation Status
| Component | Path | Status |
|---|---|---|
| QNN session helper | `src/common/session.py` | Implemented |
| Local vector store | `src/rag/store.py` | Implemented |
| App entry point | `src/app.py` | Skeleton |
| Audio scribe (Whisper) | `src/audio/transcribe.py` | Stub |
| Screen indexing | `src/vision/screen_index.py` | Stub |
| LLM reasoning (Llama-3.2-3B) | not started | Planned |

## 6. Repository Structure
```
assets/         Presentation PDF
docs/           Project write-up and presentation (PDF / PPTX)
models/         Model setup notes (AI Hub)
src/
  audio/        Audio capture and Whisper pipeline
  vision/       Screen capture and embeddings
  rag/          Local vector store
  common/       ONNX Runtime + QNN session helper
  app.py        Entry point
requirements.txt
```

## 7. Quick Start (Windows on ARM64)
Prerequisites: Snapdragon X Elite / X Plus laptop, Windows 11 on ARM64, Python 3.10+ (ARM64 build).

```bash
git clone https://github.com/<your-github-username>/snapsense-snapdragon-copilot.git
cd snapsense-snapdragon-copilot
pip install -r requirements.txt
python -m src.app --provider QNN --precision INT4
```

## 8. Roadmap
- **Phase 1:** NPU-optimized core engine, local audio transcription, vector document search
- **Phase 2:** multi-agent task automation integrated with HP system utility software

## 9. License
MIT
