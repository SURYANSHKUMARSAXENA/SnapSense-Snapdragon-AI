"""Ambient audio scribe (STUB): capture mic/system audio -> Whisper-Base INT8 on the NPU.

TODO:
  1. Capture audio with sounddevice (16 kHz mono, 30 s windows).
  2. Compute log-mel features, run encoder/decoder ONNX models from Qualcomm AI Hub.
  3. Emit transcript segments; extract action items with the local LLM.
"""
from src.common.session import make_session


class Transcriber:
    def __init__(self, encoder_path: str, decoder_path: str, provider: str = "QNN"):
        self.encoder = make_session(encoder_path, provider)
        self.decoder = make_session(decoder_path, provider)

    def transcribe(self, audio_chunk):
        raise NotImplementedError("Whisper decode loop not implemented yet")
