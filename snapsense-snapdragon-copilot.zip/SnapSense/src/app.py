"""SnapSense entry point (skeleton)."""
import argparse
from src.rag.store import VectorStore


def main():
    ap = argparse.ArgumentParser(description="SnapSense on-device copilot")
    ap.add_argument("--provider", default="QNN", choices=["QNN", "CPU"])
    ap.add_argument("--precision", default="INT4")
    args = ap.parse_args()
    print(f"SnapSense starting | provider={args.provider} precision={args.precision}")
    store = VectorStore()  # audio / vision / LLM pipelines plug in here
    print(f"Vector store ready ({len(store.vectors)} items). Pipelines are stubs; see README status table.")


if __name__ == "__main__":
    main()
