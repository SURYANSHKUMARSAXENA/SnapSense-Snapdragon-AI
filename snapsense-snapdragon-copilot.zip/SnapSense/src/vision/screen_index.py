"""Screen parsing (STUB): capture windows -> embeddings (CLIP-ViT / MobileNetV4) -> local index.

TODO: capture with mss, run image encoder via make_session(), store vectors in src.rag.store.
"""
import mss


def capture_screen():
    with mss.mss() as sct:
        return sct.grab(sct.monitors[1])


def embed_image(image):
    raise NotImplementedError("Image encoder not wired up yet")
