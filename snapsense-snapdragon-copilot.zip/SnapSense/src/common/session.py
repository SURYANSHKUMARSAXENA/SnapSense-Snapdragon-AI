"""Create ONNX Runtime sessions that target the Hexagon NPU via the QNN Execution Provider."""
import onnxruntime as ort


def make_session(model_path: str, provider: str = "QNN") -> ort.InferenceSession:
    if provider.upper() == "QNN":
        providers = [("QNNExecutionProvider", {"backend_path": "QnnHtp.dll"})]  # HTP = Hexagon NPU
        providers.append("CPUExecutionProvider")  # fallback for unsupported ops
    else:
        providers = ["CPUExecutionProvider"]
    return ort.InferenceSession(model_path, providers=providers)
