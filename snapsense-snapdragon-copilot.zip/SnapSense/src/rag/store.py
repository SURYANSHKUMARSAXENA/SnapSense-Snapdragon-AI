"""Minimal local vector store (working): cosine-similarity search over in-memory embeddings."""
import numpy as np


class VectorStore:
    def __init__(self):
        self.vectors, self.payloads = [], []

    def add(self, vector, payload):
        v = np.asarray(vector, dtype=np.float32)
        self.vectors.append(v / (np.linalg.norm(v) + 1e-9))
        self.payloads.append(payload)

    def search(self, query, k=5):
        if not self.vectors:
            return []
        q = np.asarray(query, dtype=np.float32)
        q = q / (np.linalg.norm(q) + 1e-9)
        scores = np.stack(self.vectors) @ q
        top = np.argsort(-scores)[:k]
        return [(float(scores[i]), self.payloads[i]) for i in top]
